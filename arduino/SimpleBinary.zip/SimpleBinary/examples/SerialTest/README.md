## Example openHAB serial communication

This example shows possible binding application using the serial interface. Part of example are device source file (SerialTest.ino) and openHAB things definition (SeriaTest.things). In a particular case, these files may need to be modified accordingly. These are mainly UART port and UART speed.

